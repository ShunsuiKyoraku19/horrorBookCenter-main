const express = require("express");
const app = express();
const path = require("path");
const db = require("./db");

app.use(express.json());
app.use(express.static(path.join(__dirname, "..", "frontend")));


// ROTAS

const authRoutes = require("./routes/authRoutes");
const livroRoutes = require("./routes/livrosRoutes");
const solicitRoutes = require("./routes/solicitacoes");

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "..", "frontend", "index.html"));
});
app.use("/auth", authRoutes);
app.use("/livros", livroRoutes);
app.use("/solicitacoes", solicitRoutes);

// INICIAR SERVIDOR
app.listen(3000, () => console.log("Servidor rodando em http://localhost:3000"));
