const express = require("express");
const router = express.Router();
const fs = require("fs");

const livrosDB = "./src/data/livros.json";

// ADICIONAR LIVRO (Bibliotecário)
router.post("/add", (req, res) => {
    const { titulo, autor } = req.body;

    const livros = JSON.parse(fs.readFileSync(livrosDB));

    const novo = {
        id: Date.now(),
        titulo,
        autor,
        disponivel: true
    };

    livros.push(novo);
    fs.writeFileSync(livrosDB, JSON.stringify(livros, null, 2));

    res.json({ msg: "Livro adicionado!", livro: novo });
});

// LISTAR LIVROS
router.get("/", (req, res) => {
    const livros = JSON.parse(fs.readFileSync(livrosDB));
    res.json(livros);
});

module.exports = router;
