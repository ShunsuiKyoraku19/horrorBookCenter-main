const express = require("express");
const router = express.Router();
const authController = require("../controllers/authController");

// CADASTRO (para combinar com cadastro.html)
router.post("/registrar", authController.registrar);

// LOGIN padrão
router.post("/login", authController.login);

// LOGIN bibliotecário
router.post("/login-bibliotecario", authController.loginBibliotecario);

module.exports = router;
