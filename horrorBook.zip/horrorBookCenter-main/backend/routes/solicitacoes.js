const express = require("express");
const router = express.Router();
const fs = require("fs");

const solicitDB = "./src/data/solicitacoes.json";
const livrosDB = "./src/data/livros.json";

// Solicitar empréstimo
router.post("/solicitar", (req, res) => {
    const { id_usuario, id_livro } = req.body;

    const solicitacoes = JSON.parse(fs.readFileSync(solicitDB));

    const nova = {
        id: Date.now(),
        id_usuario,
        id_livro,
        status: "pendente"
    };

    solicitacoes.push(nova);
    fs.writeFileSync(solicitDB, JSON.stringify(solicitacoes, null, 2));

    res.json({ msg: "Solicitação enviada!", solicitacao: nova });
});

// Listar solicitações
router.get("/", (req, res) => {
    const solicitacoes = JSON.parse(fs.readFileSync(solicitDB));
    res.json(solicitacoes);
});

// Aprovar ou recusar
router.post("/atualizar", (req, res) => {
    const { id_solicitacao, status } = req.body;

    const solicitacoes = JSON.parse(fs.readFileSync(solicitDB));
    const livros = JSON.parse(fs.readFileSync(livrosDB));

    const solicitacao = solicitacoes.find(s => s.id === id_solicitacao);
    if (!solicitacao) return res.status(404).json({ erro: "Solicitação não encontrada" });

    solicitacao.status = status;

    if (status === "aprovado") {
        const livro = livros.find(l => l.id === solicitacao.id_livro);
        if (livro) livro.disponivel = false;
        fs.writeFileSync(livrosDB, JSON.stringify(livros, null, 2));
    }

    fs.writeFileSync(solicitDB, JSON.stringify(solicitacoes, null, 2));

    res.json({ msg: "Solicitação atualizada!", solicitacao });
});

module.exports = router;
