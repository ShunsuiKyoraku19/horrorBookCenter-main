const db = require("../db");

// Cadastro de usuário
exports.registrar = (req, res) => {
    const { nome, email, senha, tipo } = req.body;

    if (!nome || !email || !senha || !tipo) {
        return res.status(400).json({ erro: "Preencha todos os campos" });
    }

    const query = 'INSERT INTO usuarios (nome, email, senha, tipo) VALUES (?, ?, ?, ?)';

    db.query(query, [nome, email, senha, tipo], (err) => {
        if (err) {
            return res.status(500).json({ erro: 'Erro ao registrar', detalhe: err });
        }
        res.status(201).json({ mensagem: 'Usuário registrado com sucesso!' });
    });
};

// Login
exports.login = (req, res) => {
    const { email, senha } = req.body;

    const query = 'SELECT * FROM usuarios WHERE email = ? AND senha = ?';

    db.query(query, [email, senha], (err, results) => {
        if (err) return res.status(500).json({ erro: 'Erro no login' });

        if (results.length === 0) {
            return res.status(400).json({ erro: 'Credenciais inválidas' });
        }

        const usuario = results[0];

        return res.status(200).json({
            mensagem: "Login bem-sucedido!",
            usuario: {
                id: usuario.id,
                nome: usuario.nome,
                email: usuario.email,
                tipo: usuario.tipo
            }
        });
    });
};




// Login Bibliotecário
exports.loginBibliotecario = (req, res) => {
    const { email, senha } = req.body;

    const query = 'SELECT * FROM usuarios WHERE email = ? AND senha = ? AND tipo = "bibliotecario"';

    db.query(query, [email, senha], (err, results) => {
        if (err) return res.status(500).json({ erro: 'Erro no login do bibliotecário' });

        if (results.length > 0) {
            const usuario = results[0];

            res.status(200).json({
                mensagem: 'Login bibliotecário OK!',
                usuario: {
                    id: usuario.id,
                    nome: usuario.nome,
                    email: usuario.email,
                    tipo: usuario.tipo
                }
            });
        } else {
            res.status(400).json({ erro: 'Credenciais inválidas' });
        }
    });
};

