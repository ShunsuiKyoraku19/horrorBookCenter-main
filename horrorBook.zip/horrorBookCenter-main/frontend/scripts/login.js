document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('loginForm').addEventListener('submit', async (e) => {
        e.preventDefault();

        // CORREÇÃO: Use 'email' em vez de 'username'
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        try {
            const response = await fetch('http://localhost:3000/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                // CORREÇÃO: Envie 'email' em vez de 'username'
                body: JSON.stringify({ email, password }),
            });

            const result = await response.json();
            
            // Adiciona feedback visual e redirecionamento
            if (response.ok) {
                document.getElementById('Res').textContent = 'Login realizado com sucesso!';
                document.getElementById('Res').style.color = 'green';
                
                // Salva o token se existir
                if (result.token) {
                    localStorage.setItem('tokenEstudante', result.token);
                }
                
                // Redireciona após 1 segundo
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 1000);
            } else {
                document.getElementById('Res').textContent = result.message || 'Erro no login';
                document.getElementById('Res').style.color = 'red';
            }
        } catch (error) {
            console.error('Erro:', error);
            document.getElementById('Res').textContent = 'Erro ao conectar ao servidor';
            document.getElementById('Res').style.color = 'red';
        }
    });
});

// Funções de música (se precisar)
function playMusic() {
    const audio = document.getElementById("music");
    if (audio) audio.play();
}

function pauseMusic() {
    const audio = document.getElementById("music");
    if (audio) {
        audio.pause();
        audio.currentTime = 0;
    }
}