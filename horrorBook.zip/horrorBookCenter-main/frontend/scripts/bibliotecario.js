// /c:/Users/lukas/horrorBookCenter-main/frontend/scripts/bibliotecario.js
// Script para cadastro do usuário "bibliotecario"
// Inclua este arquivo em uma página que contenha um <form id="formBibliotecario"> com os campos esperados.

(() => {
    const API_URL = '/api/bibliotecarios/register'; // ajuste conforme sua API

    // Helper: cria/obtém área de mensagens
    function getMensagemArea() {
        let area = document.getElementById('mensagemBibliotecario');
        if (!area) {
            area = document.createElement('div');
            area.id = 'mensagemBibliotecario';
            area.style.marginTop = '1rem';
            const form = document.getElementById('formBibliotecario') || document.body;
            form.insertAdjacentElement('afterend', area);
        }
        return area;
    }

    function mostrarMensagem(texto, tipo = 'info') {
        const area = getMensagemArea();
        area.innerText = texto;
        area.style.color = tipo === 'error' ? '#a00' : tipo === 'success' ? '#070' : '#333';
        area.style.border = tipo === 'error' ? '1px solid #f5c6cb' : tipo === 'success' ? '1px solid #c3f7c3' : 'none';
        area.style.padding = '0.5rem';
        area.style.borderRadius = '4px';
    }

    // Validações básicas
    function validarDados(dados) {
        if (!dados.nome || dados.nome.trim().length < 3) {
            return 'Informe um nome com pelo menos 3 caracteres.';
        }
        if (!/^\S+@\S+\.\S+$/.test(dados.email)) {
            return 'Informe um e-mail válido.';
        }
        if (!dados.senha || dados.senha.length < 6) {
            return 'A senha deve ter pelo menos 6 caracteres.';
        }
        if (dados.senha !== dados.confirmarSenha) {
            return 'As senhas não coincidem.';
        }
        if (!dados.cracha || dados.cracha.trim().length < 3) {
            return 'Informe o número do crachá do bibliotecário.';
        }
        return null;
    }

    async function cadastrarBibliotecario(dados, btn) {
        btn.disabled = true;
        const btnText = btn.innerText;
        btn.innerText = 'Cadastrando...';

        try {
            const res = await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    nome: dados.nome.trim(),
                    email: dados.email.trim().toLowerCase(),
                    senha: dados.senha,
                    cracha: dados.cracha.trim(),
                    telefone: dados.telefone ? dados.telefone.trim() : undefined
                })
            });

            const body = await res.json().catch(() => ({}));

            if (res.ok) {
                mostrarMensagem('Cadastro realizado com sucesso.', 'success');
                // opcional: guardar token e redirecionar
                if (body.token) {
                    localStorage.setItem('tokenBibliotecario', body.token);
                }
                // limpar formulário
                document.getElementById('formBibliotecario')?.reset();
                return;
            }

            // tratar erros
            if (body && body.message) {
                mostrarMensagem(body.message, 'error');
            } else if (body && body.errors) {
                mostrarMensagem(Object.values(body.errors).flat().join('; '), 'error');
            } else {
                mostrarMensagem(`Erro ao cadastrar (status ${res.status}).`, 'error');
            }
        } catch (err) {
            mostrarMensagem('Erro de conexão. Tente novamente.', 'error');
            console.error(err);
        } finally {
            btn.disabled = false;
            btn.innerText = btnText;
        }
    }

    // Inicializa manipulador do formulário
    function init() {
        const form = document.getElementById('formBibliotecario');
        if (!form) return;

        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const data = {
                nome: form.querySelector('[name="nome"]')?.value || '',
                email: form.querySelector('[name="email"]')?.value || '',
                senha: form.querySelector('[name="senha"]')?.value || '',
                confirmarSenha: form.querySelector('[name="confirmarSenha"]')?.value || '',
                cracha: form.querySelector('[name="cracha"]')?.value || '',
                telefone: form.querySelector('[name="telefone"]')?.value || ''
            };

            const erro = validarDados(data);
            if (erro) {
                mostrarMensagem(erro, 'error');
                return;
            }

            const btn = form.querySelector('button[type="submit"]') || form.querySelector('input[type="submit"]') || { disabled: false, innerText: 'OK' };
            cadastrarBibliotecario(data, btn);
        });
    }

    // Executa na carga do DOM
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();