// /c:/Users/lukas/horrorBookCenter-main/frontend/scripts/estudante.js
const usuario = JSON.parse(localStorage.getItem("usuario")) || {};
let listaCompleta = [];

const inputPesquisa = document.getElementById("pesquisa");
const catalogoEl = document.getElementById("catalogo");

// carregar todos os livros inicialmente
async function carregarLivros() {
    try {
        const resp = await fetch("/livros");
        listaCompleta = await resp.json();
        exibirLivros(listaCompleta);
    } catch (e) {
        console.error("Erro ao carregar livros:", e);
    }
}

function exibirLivros(lista) {
    catalogoEl.innerHTML = "";
    lista.forEach(livro => {
        const imagem = livro.imagem ? livro.imagem : "images/default.png";
        catalogoEl.innerHTML += `
            <div class="livro-card">
                <img src="${imagem}" alt="Capa do livro">
                <h3>${livro.titulo}</h3>
                <p>${livro.autor}</p>
                <p><b>${livro.disponivel ? "Disponível" : "Indisponível"}</b></p>
                ${
                    livro.disponivel
                        ? `<button class="btn" onclick="solicitar(${livro.id})">Alugar</button>`
                        : `<button class="btn-cancelar" onclick="cancelar(${livro.id})">Cancelar</button>`
                }
            </div>
        `;
    });
}

// pesquisa local ao digitar (filtra lista já carregada)
inputPesquisa.addEventListener("input", (e) => {
    const texto = e.target.value.toLowerCase();
    const filtrados = listaCompleta.filter(livro =>
        livro.titulo.toLowerCase().includes(texto) ||
        livro.autor.toLowerCase().includes(texto)
    );
    exibirLivros(filtrados);
});

// ao pressionar ENTER, faz busca no servidor (banco de dados)
inputPesquisa.addEventListener("keydown", async (e) => {
    if (e.key === "Enter") {
        e.preventDefault();
        const texto = inputPesquisa.value.trim();
        if (!texto) {
            // se campo vazio, recarrega tudo
            carregarLivros();
            return;
        }
        await buscarNoServidor(texto);
    }
});

// função que consulta o backend por resultados no banco
async function buscarNoServidor(texto) {
    try {
        // endpoint sugerido: /livros?search=...
        const resp = await fetch(`/livros?search=${encodeURIComponent(texto)}`);
        if (!resp.ok) {
            // se backend usar outro endpoint, ajuste aqui
            throw new Error(`HTTP ${resp.status}`);
        }
        const resultados = await resp.json();
        // atualiza listaCompleta para manter consistência com a busca do servidor
        listaCompleta = resultados;
        exibirLivros(resultados);
    } catch (e) {
        console.error("Erro ao buscar no servidor:", e);
        alert("Erro ao buscar livros no servidor.");
    }
}

// solicitar livro
async function solicitar(idLivro) {
    try {
        await fetch("/solicitacoes/solicitar", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                id_usuario: usuario.id,
                id_livro: idLivro
            })
        });
        alert("Solicitação enviada!");
        carregarLivros();
    } catch (e) {
        console.error("Erro ao solicitar:", e);
        alert("Erro ao enviar solicitação.");
    }
}

// cancelar solicitação / aluguel
async function cancelar(idLivro) {
    try {
        await fetch("/solicitacoes/cancelar", {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                id_usuario: usuario.id,
                id_livro: idLivro
            })
        });
        alert("Aluguel cancelado!");
        carregarLivros();
    } catch (e) {
        console.error("Erro ao cancelar:", e);
        alert("Erro ao cancelar aluguel.");
    }
}

// expor para onclick inline no HTML
window.solicitar = solicitar;
window.cancelar = cancelar;

carregarLivros();